# crowdhound-examples

This project provides examples and a tutorial for how to add Crowdhound to a website.

While going through the tutorial you will view the examples, and add the functionality for **comments**, **discussions**, a **blog**, **chat**, **page view counting**, **user reviews and ratings**, and an **events calendar** to a locally hosted website named [snailadvisor.com](http://localhost:8080/exercises/snailadvisor.com).


![2016-09-01_10-56-07](https://cloud.githubusercontent.com/assets/848697/18153876/ce33e6f0-7032-11e6-9a8a-38c34fd9a0d8.png)

To start, see the [Wiki](https://github.com/tooltwist/crowdhound-examples/wiki).
